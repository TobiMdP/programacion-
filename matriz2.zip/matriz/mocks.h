#ifndef MOCKS_H_INCLUDED
#define MOCKS_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "stAlumno.h"

void cargaNombre (char nombre []);
void cargaApellido (char apellido []);
void cargaDni (char dni []);
int cargaLegajo ();

#endif // MOCKS_H_INCLUDED
