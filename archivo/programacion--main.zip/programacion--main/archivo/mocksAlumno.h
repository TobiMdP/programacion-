#ifndef MOCKSALUMNO_H_INCLUDED
#define MOCKSALUMNO_H_INCLUDED
#include "stAlumno.h"
#include <stdio.h>
#include <stdlib.h>
int cargaArregloAlumnosAuto (stAlumno a[], int dim);

#endif // MOCKSALUMNO_H_INCLUDED

